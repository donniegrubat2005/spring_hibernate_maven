package com.springmvc_crud.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc_crud.dao.UserDao;
import com.springmvc_crud.model.User;
import com.springmvc_crud.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	UserDao userDao;
	
	@Autowired
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public void saveOrUpdate(User user) {
		userDao.saveOrUpdate(user);

	}

	@Override
	public User finduserbyid(int id) {
		return userDao.finduserbyid(id);
	}

	@Override
	public void delete(int id) {
		userDao.delete(id);

	}

	@Override
	public List<User> getAllUser() {
		return userDao.getAllUser();
	}

}

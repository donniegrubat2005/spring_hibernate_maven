package com.springmvc_crud.service;

import java.util.List;

import com.springmvc_crud.model.User;

public interface UserService {

	public void saveOrUpdate(User user);
	public User finduserbyid(int id);
	public void delete(int id);
	public List<User> getAllUser();

}

package com.springmvc_crud.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc_crud.dao.UserDao;
import com.springmvc_crud.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	private Session getSession() {
		
	return sessionFactory.getCurrentSession();
	}
	
	@Override
	public void saveOrUpdate(User user) {
		getSession().saveOrUpdate(user);

	}

	@Override
	public User finduserbyid(int id) {
		User user= (User) getSession().get(User.class, id);
		return user;
	}

	@Override
	public void delete(int id) {
		User user= (User) getSession().get(User.class, id);
        getSession().delete(user);
	}

	@Override
	
	public List<User> getAllUser() {
		Criteria criteria=getSession().createCriteria(User.class);
		return (List<User>) criteria.list();
	}

}
